from Booksearch import *
from Bookcheckout import *

def bookUpdate():
    """This function is used to save data into the Database.txt file"""
    f = open("Database.txt","w")
    for book in BooksInfo:
        update = book[0]+","+book[1]+","+book[2]+","+book[3]+","+book[4]+","+book[5] + "\n"
        f.write(update)
    f.close()

def Return_book():
    """This function asks the user to input their member ID and the book ID, in order to
return a certain book. It performs validity checks, and if it's true, it updates the
database. If it's false, it gives an error message."""
    bookId = input("Please enter the ID of the book that you \
want to return:\n")
    memberId = int(input("Please enter your member Id:\n"))
    if memberId>999 and memberId<10000:
                    for book in BooksInfo:
                        if book[1] == bookId:
                            if book[5] == '0':
                                return "Error, book was already available in system."
                            else:
                                for book in BooksInfo:
                                    if book[1] == bookId:
                                        book[5] = '0'
                                        bookUpdate()
                                        return "Book is returned successfully."
                    return "Error, the book isn't in the library system."
    return "Invalid Member ID, must be 4 digits"

