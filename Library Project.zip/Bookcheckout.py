
from Booksearch import *
from Bookreturn import *

def ID():
    MemberID = int(input("Enter Member ID number:\n"))
    if MemberID>999 and MemberID<10000:
        return MemberID
    else:
        print ("Invalid member ID, must be 4 digits")

def BookID():
    """This function tells the user whether or not a book is
available in the system or not by searching using
Book ID. It is specifically designed to be used
in another function checkout_book(ID)"""
    ID = input("Enter Book ID number that you want to checkout:\n")
    for book in BooksInfo:
        if book[1] == ID:
            if book[5] == '0':
                return ID
    else:
        return "Book already taken"


def savebook():
    f = open("Database.txt","w")
    for book in BooksInfo:
        newInfo = book[0]+","+book[1]+","+book[2]+","+book[3]+","+book[4]+","+str(book[5])+"\n"
        f.write(newInfo)
    f.close()
def checkout_book():
    Id = ID()
    bookId = BookID ()
    for identity in BooksInfo:
        if identity[1] == bookId:
            identity [5] = Id
            savebook()
            return "Book checked out successfully."
        return "Error, the book isn't in the library"
    
        
