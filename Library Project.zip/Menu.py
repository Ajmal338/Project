from tkinter import *
from Booksearch import *
import Bookcheckout as c
import Bookreturn as r
def menu():
    """
    Displays dfferent menu options for the librarian
    to choose from
    """
    print ("\t")
    print ("Please select an option below:")
    print ("\t(s) Search for a book")
    print ("\t(c) Checkout a book")
    print ("\t(r) Return a book")
    print ("\t(q) Quit menu")




######
#Main#
######

while True:
    menu()
    menuchoice = input("=> ")
    if menuchoice == 'q':
        break
    elif menuchoice == 's':
        s=searchbookbyTitle(input("Please enter the name of the book:\n"))
        print(s)
    elif menuchoice == 'c':
        print(c.checkout_book())
    elif menuchoice == 'r':
        print(r.Return_book())
    else:
        print("we do not have that option.")
