
BooksInfo = []
def book_data():
    """Takes all data stored in the relevant (.txt) file
and orders them into a list of lists"""
    f = open("Database.txt","r")
    for line in f:
        cleanup=line.strip()
        Data=cleanup.split(",")
        BooksInfo.append(Data)
    f.close

book_data()


def searchbookbyTitle(Title):
    """This function searches for a book based on the
title that the user gives, and retrieves all the relevant
information of that book."""
    for book in BooksInfo:
        if book[0] == Title:
            return book
    return "That book is unavailable"
        
